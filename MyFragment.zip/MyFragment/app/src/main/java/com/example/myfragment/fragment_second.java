package com.example.myfragment;

import android.app.Activity;

public class fragment_second extends Activity {
}
